import React, { useState, useEffect } from "react";

function ProjectCard({ project }) {
  return (
    <div className="cardcontainer border">
      <div className="row">
        <div className="new">
          <div>
            <span>New</span>
          </div>
        </div>
        <div className="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 cardheadingsect">
          <div>
            <span>Bid Date: {project.bidDate}</span>
            <h2>{project.title}</h2>
            <div className="loc">
              <img className="pdf" alt="" src="./images/location.png" />
              <span className="">{project.location}</span>
            </div>

            <div className="aut-progress">
              <span className="Authority">{project.company}</span>
              <div className="progress-background">
                <div className="qto-progress">
                  <span>
                    QTO in progress <span>{project.progress}%</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 card-right">
          <div className="bid-ammout">
            <span>Bid Amount: ${project.amount}</span>
          </div>
          <button className="NB smd">See More Details</button>
          <button className="adtocart">Add to Cart</button>
        </div>
      </div>
    </div>
  );
}

export default function CardContainer() {
  const [projectData, setProjectData] = useState(null);
  const [sortedProjects, setSortedProjects] = useState([]);

  useEffect(() => {
    fetch("https://qtohub.com/fetchprojects")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        setProjectData(data);
      })
      .catch((error) => {
        console.error("Fetch Error:", error);
      });
  }, []);

  useEffect(() => {
    if (projectData) {
      // Ensure projectData is not null before initializing sortedProjects
      setSortedProjects([...projectData]);
    }
  }, [projectData]); // Update sortedProjects when projectData changes

  const sortProjects = (sortBy) => {
    let sortedProjectsCopy = [...sortedProjects];

    switch (sortBy) {
      case "bidDate":
        sortedProjectsCopy.sort(
          (a, b) => new Date(a.bidDate) - new Date(b.bidDate)
        );
        break;
      case "title":
        sortedProjectsCopy.sort((b, a) => a.title.localeCompare(b.title));
        break;
      case "amount":
        sortedProjectsCopy.sort((b, a) => a.amount - b.amount);
        break;
      // Add more sorting options as needed
      default:
        break;
    }

    setSortedProjects(sortedProjectsCopy);
  };

  return (
    <>
      <div>
        <button onClick={() => sortProjects("bidDate")}>
          Sort by Bid Date
        </button>
        <button onClick={() => sortProjects("title")}>Sort by Title</button>
        <button onClick={() => sortProjects("amount")}>Sort by Amount</button>
      </div>

      <div>
        {/* Conditional rendering to handle projectData being null */}
        {projectData ? (
          sortedProjects.map((project, index) => (
            <ProjectCard key={index} project={project} />
          ))
        ) : (
          <div>Loading...</div>
        )}
      </div>
    </>
  );
}
